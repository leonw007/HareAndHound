This is the custom front-end for your hare-and-hounds game.

Download a zip of the files and dump it into the src/main/resources/public/ folder of your project and you should be good to go.

We suggest that you use the Todo app source tree as a starting point for the other files.
